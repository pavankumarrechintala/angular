import { Component, OnInit } from '@angular/core';
import { ExamService } from '../sevices/exam.service';
import {Router} from '@angular/router';


@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.css']
})
export class ResultComponent implements OnInit {

  constructor(private ps:ExamService, private rt:Router) { }

  ngOnInit() {
    this.ps.getAnswers().subscribe((data : any)=>{
      this.ps.correctAnswerCount=0;
      this.ps.qns.forEach((e,i)=>{
        if(e.answer==data[i])
        this.ps.correctAnswerCount++;
        e.correct=data[i];

      })
    })
  }

}
