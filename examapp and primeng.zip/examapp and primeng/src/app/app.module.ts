import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule } from '@angular/common/http';
import {AccordionModule} from 'primeng/accordion'; 
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {DialogModule} from 'primeng/dialog';


import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { ViewquestionComponent } from './viewquestion/viewquestion.component';
import { ResultComponent } from './result/result.component';



var totalroutes:Routes=[

  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'result',component: ResultComponent},
  {path:'',component:LoginComponent,pathMatch:'full'},

]


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    AddquestionComponent,
    ViewquestionComponent,
    ResultComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(totalroutes),FormsModule,HttpClientModule,AccordionModule,BrowserAnimationsModule,InputTextModule,ButtonModule
,DialogModule  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
