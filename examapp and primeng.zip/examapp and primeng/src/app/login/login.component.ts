import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ExamService} from '../sevices/exam.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  display: boolean = false;
  constructor(private rt:Router,private ps:ExamService) { }

  showDialog() {
    this.display = true;
}

  fnlog(u,p){
    console.log(u+p)
this.ps.login(u,p).subscribe((data) => {

if (data.length > 0) {
localStorage.setItem("uname",u)

this.rt.navigate(['register'])
}
else{
alert('invalid credintials')
}
})
}
  ngOnInit() {
  }

}
