export class state{
hyd:string
chennai:string
jaipur:string

}