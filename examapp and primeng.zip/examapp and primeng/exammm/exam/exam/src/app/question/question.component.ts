import { Component, OnInit } from '@angular/core';
import { ExamService } from '../services/exam.service';
import {question} from '../../models/question'
import {Router} from '@angular/router'
@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
  uu : question
  constructor(private ps : ExamService,private rt : Router) {
    this.uu = new question()
   }

   btnClick(regFrm){
    if(regFrm.valid){
     
      this.ps.question(this.uu).subscribe((data)=>{
        console.log(data);
        alert(JSON.stringify(data))
        console.log('added success')
        this.rt.navigate(['post'])
      })
    
    }
    else{
      alert('invalid')
    }
  }

  ngOnInit() {
    
  }


}

