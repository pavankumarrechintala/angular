import { Injectable } from '@angular/core';
import {question} from '../../models/question'
import {Router} from '@angular/router'
import {HttpHeaders,HttpClient} from '@angular/common/http';
import {Observable} from '../../../node_modules/rxjs';
import { marks} from '../../models/marks'
@Injectable({
  providedIn: 'root'
})
export class ExamService {
  admin:string="http://localhost:4600/ad";
  constructor(private ht:HttpClient ) { }
  adminLogin(id:number,pwd:string):Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
  return this.ht.get('http://localhost:4600/ad'+'/'+id+'/'+pwd,{responseType:'json'})
  
  }
  viewqyes(technology:string):Observable<any>{
     const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
     }
  return this.ht.get('http://localhost:4600/questi'+'/'+technology,{responseType:'json'})
  }
  viewques(tech:string,id:number):Observable<any>{
   
     const httpOptions = {
       headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
  return this.ht.get('http://localhost:4600/quest'+'/'+tech+'/'+id,{responseType:'json'})
  }
  postmarks(marks:marks){
    const httpOptions = { 
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.ht.post('http://localhost:4600/marks1',JSON.stringify(marks),httpOptions)
  }
  delmarks(){
 
    const httpOptions = { 
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
return this.ht.delete('http://localhost:4600/marksdel',{responseType:'json'})
  }
  getscore(){
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
     }
  return this.ht.get('http://localhost:4600/total',{responseType:'json'})

  }
  getmarks(){
    const httpOptions = {
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
     }
  return this.ht.get('http://localhost:4600/marks',{responseType:'json'})

  }
  question(question:question){
    const httpOptions = { 
      headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }
    return this.ht.post('http://localhost:4600/questions',JSON.stringify(question),httpOptions)
  }
}
