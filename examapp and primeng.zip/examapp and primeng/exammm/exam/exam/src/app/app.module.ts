import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { RouterModule, Routes } from '@angular/router'
import { HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { TaketestComponent } from './taketest/taketest.component';
import { TestComponent } from './test/test.component';
import { MarksComponent } from './marks/marks.component';
import { QuestionComponent } from './question/question.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { InstructionsComponent } from './instructions/instructions.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
const myroutes:Routes=[
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  { path:'admin',component:AdminComponent },
  {path:'contactus',component:ContactusComponent},
  {path:'taketest',component:TaketestComponent},
  {path:'test/:technology',component:TestComponent},
  {path:'instructions',component:InstructionsComponent},
  {path:'marks',component:MarksComponent},
  {path:'questions',component:QuestionComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    TaketestComponent,
    TestComponent,
    MarksComponent,
    QuestionComponent,
    ContactusComponent,
    HomeComponent,
    InstructionsComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(myroutes),FormsModule,HttpClientModule,BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
