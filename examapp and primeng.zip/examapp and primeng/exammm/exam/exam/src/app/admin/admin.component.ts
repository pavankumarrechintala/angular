import { Component, OnInit } from '@angular/core';
import {ExamService} from '../services/exam.service';

import {Router} from '@angular/router'
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  adminid:string
  pwd:string
  constructor(private router:Router,private ms:ExamService) { }
  btnLoginClick(adminid,pwd) {

  
          this.ms.adminLogin(adminid,pwd).subscribe((data) => {
            console.log(data)
              if (data.length > 0) {
                  localStorage.setItem("adminid", this.adminid)
                  this.router.navigate(['home'])
              }
              else {
                  alert('Invalid User...')
              }
          })
      }
    

  ngOnInit() {
  }

}
