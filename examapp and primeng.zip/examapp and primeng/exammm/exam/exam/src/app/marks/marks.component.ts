import { Component, OnInit } from '@angular/core';
import {ExamService} from '../services/exam.service'
@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
ques:any;
qyes:any[];
  constructor(private ms:ExamService) { }

  ngOnInit() {
    this.ms.getmarks().subscribe((data)=>{
    
      this.ques=data
   })
   this.ms.getscore().subscribe((data)=>{
     this.qyes=data[0]
   })

  }

}
