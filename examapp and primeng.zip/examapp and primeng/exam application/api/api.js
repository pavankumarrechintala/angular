var fs=require('fs')
var path=require('path')
var bodyparser=require('body-parser')
var express=require('express')
var promise=require('bluebird')
var pav=express();

var options={promiseLib:promise}
var total=require('pg-promise')(options)
 var cs='postgres:postgres:root1@localhost:5432/pavanexam'

 var db=total(cs)
 
 pav.set('port',process.env.PORT||4300)


 pav.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Methods', '*');
 res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
 next();
})

pav.use(bodyparser.urlencoded({limit:"50mb", extended:true}));
pav.use(bodyparser.json({limit:"50mb"}));


pav.use(express.static(path.join(__dirname,'images')))
pav.get('/',(req,res)=>{
res.send('DATBASE CONNECTED')
})




pav.get('/user',(req,res,next)=>{
    db.any('select * from users').then(
        (data)=>{
            res.send(data)
        })
     })


     pav.get('/Question',(req,res,next)=>{
        db.any('select * from Questions').then(
            (data)=>{
                res.send(data)
            })
         })
        

    
         pav.get('/examiner',(req,res,next)=>{
            db.any('select * from admin').then(
                (data)=>{
                    res.send(data)
                })
             })
            
       pav.post('/register',(req,res,next)=>{    
        var i=req.body.pid
        var a=req.body.Username
        var st=req.body.Email
        var ct=req.body.Score
        var c=req.body.TimeSpent
         var p=req.body.Password
      
    db.any('insert into users(pid,name,email,score,timespent,password) values($1,$2,$3,$4,$5,$6)',[i,a,st,ct,c,p]).then((data)=>{
    
        res.send({'message':'INSERTED REGISTER FORM'})
    })
    
    
       })

       pav.get('/login/:id/:pwd',(req,res,next)=>{
        
    var pid=req.params.id
    var pw=req.params.pwd
    db.any('select * from users where name=$1 and password=$2',[pid,pw]).then(
        (data)=>{
            res.send(data)
    
   })
})

pav.post('/addquestion', (req, res, next) => {
    console.log(req.body)
    var i = req.body.qnid
    var t = req.body.technology
    var q = req. body.qus
    var o1 =req.body.option1
    var o2 =req.body.option2
    var o3 =req.body.option3
    var o4 =req.body.option4
    var a = req.body.answer


    db.any('insert into questions(qnid,tech,qn,option1,option2,option3,option4,answer) values($1,$2,$3,$4,$5,$6,$7,$8)', [i,t,q,o1,o2,o3,o4,a]).then(
        (data) => {
            res.send({ 'message': 'Saved Successssssss...' })
        }
    )
})


pav.get('/getquestion/:name',(req,res,next)=>{
    var n = req.params.name;
  
          
    db.any('select qnid,tech,qn,option1,option2,option3,option4,answer from questions where tech=$1',n).then(
   
        (data)=>{
            

            console.log(data)
            res.send(data)
        })
     })



             pav.listen(pav.get('port'),(err)=>{
                if(err)
                console.log('server not strated ...')
                else 
                console.log('server Started at  : http://localhost:4300')
                })
                





