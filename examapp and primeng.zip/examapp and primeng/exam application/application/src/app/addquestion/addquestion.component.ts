import { Component, OnInit } from '@angular/core';
import {questions} from '../model/login'
import { Router } from '@angular/router';
import { ExamService } from '../sevices/exam.service';
@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {
  qus: questions
  constructor(private rt:Router,private ps:ExamService) {
    this.qus=new questions()
   }


   btnsubmitonclick(pavan: any) {
 

    if (pavan.valid) {
      console.log(JSON.stringify(this.qus))
      this.ps.SaveEmployee(this.qus).subscribe((data) => {
 location.reload();

      })
    }
      
  }
  ngOnInit() {
  }

}
