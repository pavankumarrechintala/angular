import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ExamService} from '../sevices/exam.service';
import  {Login} from '../model/login'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  display: boolean = false;
// name:any="";
// pass:string="";
// pav:Login
  constructor(private rt:Router,private ps:ExamService) {
    // this.pav=new Login()
   }

  showDialog() {
    this.display = true;
}

  fnlog(u,p){
  
    this.ps.login(u,p).subscribe((data) => {

if (data.length > 0) {
localStorage.setItem("uname",u)

this.rt.navigate(['home'])
}
else{
alert('invalid credintials')
}
})
}
    

  ngOnInit() {
  }

}
