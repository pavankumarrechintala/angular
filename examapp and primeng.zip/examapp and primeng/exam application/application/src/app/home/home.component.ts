import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  display: boolean = false;
  constructor(private rt:Router) { }
  showDialog(ty) {
    console.log(ty)
    localStorage.setItem('tech',ty)
    this.display = true;
}


// fn(){

//   this.rt.navigate(['home'])
// }
fy(){
var n = localStorage.getItem('tech')
console.log(n);
  this.rt.navigate(['getquestion/'+n])
}
  ngOnInit() {
  }

}
