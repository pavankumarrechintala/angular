import { Injectable } from '@angular/core';
import {Login} from '../model/login';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import {register} from '../model/reg'
import {questions} from '../model/login'


@Injectable({
  providedIn: 'root'
})
export class ExamService {
  apiurl:string="http://localhost:4300/register";
  apiurl1:string="http://localhost:4300/addquestion";

  qns:any[];
  seconds:number;
  timer;
  qnProgress:number;
  
  constructor(private ht:HttpClient) { }



  displayTimeElapsed(){
    return Math.floor(this.seconds / 3600) +':' + Math.floor(this.seconds / 60)  + ':' + Math.floor(this.seconds % 60)
  }

  registermember(rp:register){
    const httpOptions={
      headers:new HttpHeaders({'Content-Type':'application/json'})
    }
    return this.ht.post(this.apiurl,JSON.stringify(rp),httpOptions)
    
    }

    login(name:any,pass:any):Observable<any>{

      return this.ht.get("http://localhost:4300/login"+'/'+name+'/'+pass,{responseType:'json'})
      }

SaveEmployee(qus:questions ):Observable<any> {
  console.log(JSON.stringify(qus))
  const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  } 
  return this.ht.post(this.apiurl1, JSON.stringify(qus), httpOptions)
}



getQuestions(n) :Observable <any>{
  return this.ht.get("http://localhost:4300/getquestion/"+n,{responseType:'json'})
  console.log(JSON.stringify(n))
}
getAnswers(){

  
}

}