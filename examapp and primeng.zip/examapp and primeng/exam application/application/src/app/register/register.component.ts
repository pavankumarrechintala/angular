import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ExamService} from '../sevices/exam.service';
import {register} from '../model/reg';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  reg:register
  constructor(private rt:Router,private ps:ExamService) {
    this.reg=new register();
   }

  btnclk(regfrm){

   
    if(regfrm.valid){
      
      this.ps.registermember(this.reg).subscribe((data) => {
        console.log(data); 
       alert(JSON.stringify(data))
    console.log("Registration Completed")
      this.rt.navigate(['login'])
    })}
  
  else{
    alert('Not inserted');
  }
    }
  ngOnInit() {
  }

}
