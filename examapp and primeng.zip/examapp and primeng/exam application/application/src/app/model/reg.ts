export class  register{

pid:number
Username:string
Email:any
Password:string
Score:number
TimeSpent:number
}