export class Login{
    userid:any
    password:string
}


export class questions{

    qnid:number
    technolgy:string
    qus:string
    option1:string
    option2:string
    option3:string
    option4:string
    answer:string
}