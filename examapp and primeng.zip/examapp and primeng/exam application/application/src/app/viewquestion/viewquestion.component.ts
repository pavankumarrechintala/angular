import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ExamService } from '../sevices/exam.service';
import { questions } from '../model/login';


@Component({
  selector: 'app-viewquestion',
  templateUrl: './viewquestion.component.html',
  styleUrls: ['./viewquestion.component.css']
})
export class ViewquestionComponent implements OnInit {

  constructor(private rt:Router,private ps:ExamService,private ar:ActivatedRoute) { 
   
  }
  qns:questions
Options:any[]=[];
  ngOnInit() {
    this.ps.seconds=0;
    this.ps.qnProgress=0;
var n = this.ar.snapshot.params.name;
    this.ps.getQuestions(n).subscribe((data)=> {
      console.log(data)
    
      //this.qns=data
        this.ps.qns=data;
        this.startTimer();
     this.Options.push(this.ps.qns[0].option1);
     if(this.ps.qnProgress++)
     this.Options.push(this.ps.qns[0].option2);
     this.Options.push(this.ps.qns[0].option3);
     this.Options.push(this.ps.qns[0].option4);
    
 console.log(this.Options)   
    } 
    )

  }
  startTimer(){
    this.ps.timer=setInterval(()=>{
    
      this.ps.seconds++;
    },1000);
  }


  Answer(qID,choice){
    this.ps.qns[this.ps.qnProgress].answer =choice;
  
    this.ps.qnProgress++;
    if(this.ps.qnProgress==6){
      clearInterval(this.ps.timer);
      this.rt.navigate(['/result']);
    }
  }
}
