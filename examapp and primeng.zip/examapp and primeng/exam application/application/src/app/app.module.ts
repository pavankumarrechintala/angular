import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule } from '@angular/common/http';
import {AccordionModule} from 'primeng/accordion'; 
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import {InputTextModule} from 'primeng/inputtext';
import {ButtonModule} from 'primeng/button';
import {DialogModule} from 'primeng/dialog';


import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { ViewquestionComponent } from './viewquestion/viewquestion.component';
import { ResultComponent } from './result/result.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';



var totalroutes:Routes=[

  {path:'home',component:HomeComponent},
  {path:'addquestion',component: AddquestionComponent},
  {path:'register',component:RegisterComponent},
  {path:'login',component:LoginComponent},
  {path:'result',component: ResultComponent},
  {path:'getquestion/:name',component:ViewquestionComponent },
  {path:'',component:LoginComponent,pathMatch:'full'},

]


@NgModule({
  declarations: [
    AppComponent,
  
    LoginComponent,
    AddquestionComponent,
    ViewquestionComponent,
    ResultComponent,
    HomeComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(totalroutes),FormsModule,HttpClientModule,AccordionModule,BrowserAnimationsModule,InputTextModule,ButtonModule
,DialogModule  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
