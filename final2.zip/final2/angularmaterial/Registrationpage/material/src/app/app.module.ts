import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{Routes,RouterModule} from '@angular/router'
import { AppComponent } from './app.component';


import{FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatCheckboxModule, MatStepperModule, MatIconModule, MatTableModule} from '@angular/material';
import { MatFormFieldModule} from '@angular/material';
import {MatInputModule} from '@angular/material';
import {MatRadioModule} from '@angular/material';
import {MatDatepickerModule} from '@angular/material';
import{MatNativeDateModule} from '@angular/material';
import{MatSelectModule} from '@angular/material';
import{MatButtonModule} from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule,MatCheckboxModule,MatFormFieldModule,MatInputModule,
    MatRadioModule,MatDatepickerModule,MatNativeDateModule,MatSelectModule,MatButtonModule,
    MatStepperModule,MatIconModule,
    FormsModule,ReactiveFormsModule,HttpClientModule,MatTableModule
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
