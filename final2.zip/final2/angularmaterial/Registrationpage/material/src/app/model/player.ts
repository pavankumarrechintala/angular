export class Player{

id:number
name:string
pno:number
firstname:string
lastname:string
totalm:string

}
