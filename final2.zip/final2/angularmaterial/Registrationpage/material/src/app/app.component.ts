import { Component } from '@angular/core';
import {Player} from './model/player';
import {PlayerService} from'./services/player.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

 
  plyobj: Player[];

  constructor(private ps: PlayerService) {
    
  }

  OnChange($event){
    console.log($event)
  }

  
value:any[]=[];
fun(id){


  if(this.value.find(x=>x==id)){

    this.value.splice(this.value.indexOf(id),1)

  }
  else{
    this.value.push(id);

  }
}



  btnDelClick(id : number){
   this.ps.deletePlayer(this.value).subscribe((data)=>{
    alert('deleted successfully')
     this.ngOnInit();
   })
  }

  ngOnInit() {

    this.ps.getplayers().subscribe((data) => {
      console.log(JSON.stringify(data))
      this.plyobj = data;
    });
  }
  displayedColumns: string[] = ['check', 'id', 'name', 'pno', 'fe', 'lastname','totalm'];

}











 

