import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Player} from '../model/player';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  constructor(private ht:HttpClient) { }

   getplayers(): Observable<any>{

return this.ht.get('http://localhost:4300/player1',{responseType:'json'})
   }

   deletePlayer(id): Observable<any> {
    
    return this.ht.delete('http://localhost:4300/player1' + '/' + id, { responseType: 'json' })
  }
}
