import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent, ConfirmationDialog } from './login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatDialogModule, MatToolbarModule, MatSnackBarModule, MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatCardModule, MatChipsModule, MatSuffix} from '@angular/material';
import { ReactiveFormsModule } from '../../node_modules/@angular/forms';
// var myRoutes: Routes = [
//   { path: 'login', component:LoginComponent },
  
// ]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ConfirmationDialog,
  ],
  entryComponents: [ConfirmationDialog],
  imports: [
    BrowserModule,
   // RouterModule.forRoot(myRoutes),
    MatDialogModule,MatToolbarModule,MatSnackBarModule,BrowserAnimationsModule,MatButtonModule,ReactiveFormsModule,MatFormFieldModule,
    MatFormFieldModule,MatIconModule,MatInputModule,MatCardModule,MatChipsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
