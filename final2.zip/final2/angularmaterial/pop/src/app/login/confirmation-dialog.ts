import { Component, OnInit } from '@angular/core';

import { Validators,FormGroup, FormBuilder } from '@angular/forms';
import { LoginComponent } from './login.component';
import { Login } from './model/login.model';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.html',
  styleUrls: ['./confirmation-dialog.css']
})
export class RegisterComponent implements OnInit {
  login:Login
  loginForm: FormGroup;
  hide = true;

  constructor(private formBuilder: FormBuilder) {
      this.login=new Login();
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      'username': [this.login.username, [
        Validators.required
      ]],
      
      'password': [this.login.password, [
        Validators.required,
        Validators.minLength(6),
        Validators.maxLength(30)
      ]],
    });
  }

  onRegisterSubmit() {
    alert(this.login.username + ' ' + this.login.password);
  }

}
