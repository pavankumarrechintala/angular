import { Component} from '@angular/core';
import { MatDialog, MatSnackBar,MatDialogRef } from '../../../node_modules/@angular/material';
import { Validators,FormGroup, FormBuilder } from '@angular/forms';
import { Login } from './model/login.model';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
 
  constructor(private dig:MatDialog,private sb:MatSnackBar) { }
  openDialog() {
    const dialogRef = this.dig.open(ConfirmationDialog);
    const snack = this.sb.open('Snack bar open before dialog');

    dialogRef.afterClosed().subscribe((showSnackBar: boolean) => {
      if (showSnackBar) {
        snack.dismiss();
        const a = document.createElement('a');
        a.click();
        a.remove();
        snack.dismiss();
        this.sb.open('Closing snack bar in a few seconds', 'Fechar', {
          duration: 2000,
        });
      }
    });
  }
}

 
 @Component({
  selector: 'confirmation-dialog',
  templateUrl: 'confirmation-dialog.html',
})
export class ConfirmationDialog {
  login:Login
  loginForm: FormGroup;
  hide = true;

  constructor(private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<ConfirmationDialog>) {
      this.login=new Login();
     }
     ngOnInit() {
      this.loginForm = this.formBuilder.group({
        'username': [this.login.username, [
          Validators.required
        ]],
        
        'password': [this.login.password, [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(30)
        ]],
      });
    }
  
    onLoginSubmit() {
      alert(this.login.username + ' ' + this.login.password +'');
    }
  
  onYesClick(): void {
    this.dialogRef.close(true);
  }

}


