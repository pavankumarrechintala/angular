import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AccordionModule} from 'primeng/accordion';  
import {RadioButtonModule} from 'primeng/radiobutton';  
import {ButtonModule} from 'primeng/button';
import {RouterModule,Routes} from '@angular/router';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {TabViewModule} from 'primeng/tabview';
import {DialogModule} from 'primeng/dialog';
import {SplitButtonModule} from 'primeng/splitbutton';
import {PasswordModule} from 'primeng/password';
import {CalendarModule} from 'primeng/calendar';
import {ContextMenuModule} from 'primeng/contextmenu';
import {GMapModule} from 'primeng/gmap';


import {InputTextModule} from 'primeng/inputtext';

import {CheckboxModule} from 'primeng/checkbox'

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastModule} from 'primeng/toast'
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import {MessageService} from 'primeng/api';
import { Page1Component } from './page1/page1.component';
import { Page2Component } from './page2/page2.component';
import {FormsModule} from '@angular/forms'
var totalroutes:Routes=[
  
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent },
  {path:'page1',component: Page1Component }
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    Page1Component,
    Page2Component
  ],
  imports: [
    BrowserModule,AccordionModule,GMapModule ,ContextMenuModule,CalendarModule,FormsModule,ToastModule, BrowserAnimationsModule,CheckboxModule,RadioButtonModule,ButtonModule,InputTextModule,RouterModule.forRoot(totalroutes),InputTextareaModule,AutoCompleteModule,SplitButtonModule,TabViewModule,DialogModule,PasswordModule


  ],
  providers: [MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
