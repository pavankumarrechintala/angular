import { Component, OnInit } from '@angular/core';
import {MessageService} from 'primeng/api'
import {Router} from '@angular/router';
  

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],

  

})


export class HomeComponent implements OnInit {
items

  constructor(private messageservice:MessageService ,private rt:Router) { }

  ngOnInit() {
    this.items = [
      {label: 'login', icon: 'pi-sign-in', routerLink: ['/login']}
    ]

    
  }
  Register() {
    console.log('here');
   
     this.messageservice.add({severity:'info', summary:'Registration Page',detail:'Data Saved'});
   //  this.rt.navigate(['login'])
}

}
