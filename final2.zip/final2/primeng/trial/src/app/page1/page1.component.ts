import { Component, OnInit } from '@angular/core';
import {MenuItem} from 'primeng/api';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {
    options: any;
  menu:MenuItem
states:string[]=['hyd','che','ban','jaipur','himayatnagar',''];

allstates:any[]


state:string

tostate:any[]
date: Date;
  constructor() { 
   
  }


  display: boolean = false;
pan:boolean=false;

  showDialog() {
      this.display = true;
  }
  showDialogg(){
   
    this.pan= true;

    }

  all(event) 
  {
    this.allstates = [];
    for(let i = 0; i < this.states.length; i++) {
        let brand = this.states[i];
        if(brand.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
            this.allstates.push(brand);
        }
    }
}

alle(event) 
  {
    this.tostate = [];
    for(let i = 0; i < this.states.length; i++) {
        let brand = this.states[i];
        if(brand.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
            this.tostate.push(brand);
        }
    }
}
  ngOnInit() {
   
    this.options = {
        center: {lat: 36.890257, lng: 30.707417},
        zoom: 12
    };

  }

}
