var bodyparser=require('body-parser')
var express=require('express')
var promise=require('bluebird')
var pav=express();

var options={promiseLib:promise}
var total=require('pg-promise')(options)
 var cs='postgres:postgres:root@localhost:5432/pavan'

 var db=total(cs)
 
 pav.set('port',process.env.PORT||4400)

 pav.use(bodyparser.urlencoded({extended:true}));
 pav.use(bodyparser.json());



 pav.get('/',(req,res)=>{
res.send('DATBASE CONNECTED')
 })

 pav.get('/student',(req,res,next)=>{
db.any('select fn_allstudentsr()').then(
    (data)=>{
        res.send(data)
    })
 })

 

pav.get('/student/:id',(req,res,next)=>{
    pid = req.params.id
   db.any('select * from students where id = $1', pid).then(
   (data)=>{
       res.send(data)
   })
   })


 

 pav.delete('/student/:id',(req,res,next)=>{

    var pid=req.params.id
    db.any('select fn_delete($1)',pid).then(
        (data)=>{
            res.send({'message':'RECORD DELETED'})
        })
   })



 
 pav.post('/student',(req,res,next)=>{
    var i=parseInt(req.body.id)
    var n= req.body.name              
  
    db.any('select fn_addstudent($1,$2)',[i,n]).then(
        (data)=>{
            res.send({'message':'INSERTED SUCCESSFULLY'})
        }

    )


   })





 
 pav.put('/student',(req,res,next)=>{
    var i=parseInt(req.body.id)
    var n= req.body.name              
 

db.any('select fn_update($1,$2)',[n,i]).then(

           (data)=>{
               res.send({'message':'updated employees table successfully'})
           }
)

   })




 
pav.listen(pav.get('port'),(err)=>{
    if(err)
    console.log('server not strated ...')
    else 
    console.log('server Started at  : http://localhost:4400')
    })
    