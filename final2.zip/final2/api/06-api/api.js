var fs=require('fs')
var path=require('path')
var bodyparser=require('body-parser')
var express=require('express')
var promise=require('bluebird')
var pav=express();

var options={promiseLib:promise}
var total=require('pg-promise')(options)
 var cs='postgres:postgres:root@localhost:5432/pavan'

 var db=total(cs)
 
 pav.set('port',process.env.PORT||4300)


 pav.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Methods', '*');
 res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
 next();
})









 pav.use(bodyparser.urlencoded({limit:"50mb", extended:true}));
 pav.use(bodyparser.json({limit:"50mb"}));


 pav.use(express.static(path.join(__dirname,'images')))
 pav.get('/',(req,res)=>{
res.send('DATBASE CONNECTED')
 })



 pav.get('/player',(req,res,next)=>{
db.any('select * from players').then(
    (data)=>{
        res.send(data)
    })
 })

 pav.get('/employee',(req,res,next)=>{
    db.any('select * from employees').then(
        (data)=>{
            res.send(data)
        })
     })


     pav.get('/register',(req,res,next)=>{
        db.any('select * from register').then(
            (data)=>{
                res.send(data)
            })
         })
        

    
         pav.get('/player1',(req,res,next)=>{
            db.any('select * from material').then(
                (data)=>{
                    res.send(data)
                })
             })
            
     
pav.get('/player/:id',(req,res,next)=>{
    pid = req.params.id
   db.any('select * from players where id = $1', pid).then(
   (data)=>{
       res.send(data)
   })
   })
    

   
pav.get('/employee/:id',(req,res,next)=>{
    pid = req.params.id
   db.any('select * from employees where id = $1', pid).then(
   (data)=>{
       res.send(data)
   })
   })

   pav.delete('/player/:id',(req,res,next)=>{

    var pid=req.params.id
    db.any('delete from players where id=$1',pid).then(
        (data)=>{
            res.send({'message':'RECORD DELETED'})
        })
   })

   pav.delete('/player1/:pid',(req,res,next) => {

     console.log('hi')
    console.log(req.params.pid);
    var q = 'delete from material where id in(' + req.params.pid + ')'
   // console.log(q);
    db.any(q).then((data) => {
        res.send({ 'message': 'deleted succesfully' })
    })


})







   pav.delete('/employee/:id',(req,res,next)=>{

    var pid=req.params.id
    db.any('delete from employee where id=$1',pid).then(
        (data)=>{
            res.send({'message':'RECORD DELETED'})
        })
   })

   pav.post('/player',(req,res,next)=>{
    var fileName = req.body.id + '.png'
    var cfn = path.join(__dirname,'images/'+fileName)
    fs.writeFile(cfn, req.body.image,'base64',(err)=>{
            if(err)
                console.log('Unable to Save Image..')
                else
                console.log('Image Saved Success...')
    })



    var i=parseInt(req.body.id)
    var n= req.body.name              
    var im="http://localhost:4300/" + req.body.id+'.png'
    var c=req.body.country
    db.any('insert  into players values($1,$2,$3,$4)',[i,n,im,c]).then(
        (data)=>{
            res.send({'message':'INSERTED SUCCESSFULLY'})
        }

    )


   })

   pav.post('/employee',(req,res,next)=>{
    var i=parseInt(req.body.id)
    var n= req.body.name              
    var c=req.body.country
    db.any('insert  into employees values($1,$2,$3)',[i,n,c]).then(
        (data)=>{
            res.send({'message':'INSERTED SUCCESSFULLY'})
        }

    )


   })

   pav.post('/register',(req,res,next)=>{
    
    var i=parseInt(req.body.userid)
    var a=req.body.address
    var st=req.body.street
    var ct=req.body.city
    var ei=req.body.emailid
    var pn=req.body.phonenumber
    var pa=req.body.password
db.any('insert into register values($1,$2,$3,$4,$5,$6,$7)',[i,a,st,ct,ei,pn,pa]).then((data)=>{

    res.send({'message':'INSERTED REGISTER FORM'})
})


   })
pav.get('/login/:uid/:pwd',(req,res,next)=>{
     console.log(u+p)
    var u=parseInt(req.params.uid)
    var p=(req.params.pwd)
db.any('select * from register where userid=$1 and password=$2',[u,p])
.then((data) => {
    res.send(data);
})
})

   pav.put('/player',(req,res,next)=>{

 

    var i=parseInt(req.body.id)
    var n= req.body.name              
    var im=req.body.image
    var c=req.body.country

db.any('update players set name=$1,image=$2,country=$3 where id=$4',[n,im,c,i]).then(

           (data)=>{
               res.send({'message':'updated players table successfully'})
           }
)

   })



   
   pav.put('/employee',(req,res,next)=>{
    var i=parseInt(req.body.id)
    var n= req.body.name              
    var c=req.body.country

db.any('update employees set name=$1,country=$2 where id=$3',[n,c,i]).then(

           (data)=>{
               res.send({'message':'updated employees table successfully'})
           }
)

   })

pav.listen(pav.get('port'),(err)=>{
    if(err)
    console.log('server not strated ...')
    else 
    console.log('server Started at  : http://localhost:4300')
    })
    