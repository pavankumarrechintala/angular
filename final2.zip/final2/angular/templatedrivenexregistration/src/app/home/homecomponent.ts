import {Component} from '@angular/core'
import {Student} from '../model/regmodel'


@Component({
       selector:'home',
       templateUrl:'./homecomponent.html',
       styleUrls:['./homecomponent.css']
    
})

export class HomeComponent{
pav:Student
    constructor(){
this.pav=new Student()
    }
}