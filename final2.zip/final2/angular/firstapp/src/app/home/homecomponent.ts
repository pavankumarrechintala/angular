import { Component } from "@angular/core";

@Component(
    {
selector:'home',
templateUrl:'homecomponent.html',
styleUrls:['homecomponent.css']


    }
)
export class HomeComponent{
private id:number=105
name:string="pavan"
employee={"name":"pavanrejintala"}
}