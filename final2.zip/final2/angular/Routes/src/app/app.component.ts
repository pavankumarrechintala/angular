import { Component, DoCheck } from '@angular/core';
import {of} from 'rxjs';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  lgval: Observable<string>

  constructor() {
  }

  private CheckLocalStore(): Observable<any> {
      return of(localStorage.getItem("uname"));
  }


  logOutClick()
  {
      localStorage.removeItem("uname")
  }

  ngDoCheck() {
      this.CheckLocalStore().subscribe((data) => { this.lgval = data })
  }

}
