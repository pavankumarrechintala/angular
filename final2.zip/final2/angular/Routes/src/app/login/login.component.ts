import { Component, OnInit } from '@angular/core';
import {Login} from '../models2/login'
import { Router } from '@angular/router';
import { PlayerService } from '../services/player.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
uid:string="";
pwd:any="";
  constructor(private rt:Router,private ps:PlayerService) {

   }
  
   btnloginClick(u,p){
          
          this.ps.login(u,p).subscribe((data) => {
            console.log(data); 
         
         if ([data].length > 0) {
          localStorage.setItem("uname",u)
        
          this.rt.navigate(['home'])
        }
      else{
        alert('invalid credintials')
      }
      })
   }
  
   
  ngOnInit() {
  }

}
