import { Component, OnInit } from '@angular/core';
import {PlayerService} from '../services/player.service'
import {Router} from '@angular/router'
@Component({
  selector: 'app-playerlist',
  templateUrl: './playerlist.component.html',
  styleUrls: ['./playerlist.component.css']
})
export class PlayerlistComponent implements OnInit {
pavan:any[]=[]
  constructor( private ps:PlayerService,private rt:Router) { }

btnDelClick(id){
  this.ps.deletePlayer(id).subscribe((data)=>{
alert(JSON.stringify(data)) 
location.reload();
})
}
btnEditClick(id){
  this.rt.navigate(['updatePlayer/'+id])
}


  ngOnInit() {
    this.ps.getAllPlayers().subscribe((res)=>{
console.log(res)
this.pavan=res

    })
  }

}
