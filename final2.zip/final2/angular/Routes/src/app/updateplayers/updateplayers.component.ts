import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router } from '@angular/router'
import { PlayerService } from '../services/player.service';
import {Players} from '../model/addplayers'
@Component({
  selector: 'app-updateplayers',
  templateUrl: './updateplayers.component.html',
  styleUrls: ['./updateplayers.component.css']
})
export class UpdateplayersComponent implements OnInit {
pav:Players
  constructor(private acr: ActivatedRoute, private ps: PlayerService, private router : Router  ) { 

    this.pav=new Players()
  }

 
  btnclk(plfrm){
    if(plfrm.valid){
      this.ps.updatePlayer(this.pav).subscribe((data)=>{
        this.router.navigate(['showallplayers'])
      })        
    }
  }
  ngOnInit() {
   let i =  parseInt(this.acr.snapshot.params["id"])
   this.ps.getPlayerById(i).subscribe((data)=>{
    this.pav = data[0];
   })
    
  }
  

}
