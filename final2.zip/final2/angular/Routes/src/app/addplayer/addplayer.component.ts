import { Component, OnInit } from '@angular/core';
import { Players } from '../model/addplayers';
import { PlayerService } from '../services/player.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-addplayer',
  templateUrl: './addplayer.component.html',
  styleUrls: ['./addplayer.component.css']
})
export class AddplayerComponent implements OnInit {
  pav: Players
  url:string=''
  constructor( private rt: Router,private ps: PlayerService, ) {

    this.pav = new Players()
  }


  btnclk(plfrm) {

    if (plfrm.valid) {
      this.pav.image = this.pav.image.replace('data:image/jpeg;base64,','')
        this.pav.image = this.pav.image.replace('data:image/jpg;base64,','')
        this.pav.image = this.pav.image.replace('data:image/png;base64,','')

      this.ps.addPlayer(this.pav).subscribe((data) => {
        console.log(data); 
       alert(JSON.stringify(data))
    
      this.rt.navigate(['showallplayers'])
    }
  )}}

  fileselect(event){
    if(event.target.files){
      var reader  = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (ev:any)=>{
        this.url = ev.target.result
        this.pav.image = reader.result
      }
    }
 }

    ngOnInit() {
    }

  }
