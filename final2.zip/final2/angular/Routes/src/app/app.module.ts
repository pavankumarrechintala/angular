import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddplayerComponent } from './addplayer/addplayer.component';
import { PlayerlistComponent } from './playerlist/playerlist.component';
import { ContactusComponent } from './contactus/contactus.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { UpdateplayersComponent } from './updateplayers/updateplayers.component';

var totalroutes:Routes=[
{path:'home',component:HomeComponent},
{path:'addplayer',component:AddplayerComponent},
{path:'showallplayers',component:PlayerlistComponent},
{path:'contactus',component:ContactusComponent},
{path:'aboutus',component: AboutusComponent},
{path:'register',component:RegisterComponent},
{path:'login',component: LoginComponent},
{path:'updatePlayer/:id',component:UpdateplayersComponent}
];


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutusComponent,
    AddplayerComponent,
    PlayerlistComponent,
    ContactusComponent,
    RegisterComponent,
    LoginComponent,
    UpdateplayersComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(totalroutes),FormsModule,HttpClientModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
