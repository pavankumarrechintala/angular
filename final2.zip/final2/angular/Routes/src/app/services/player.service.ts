import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';
import {Players} from '../model/addplayers';
import { RegisterPlayer } from '../models1/regmodel';
import {Login} from '../models2/login'
@Injectable({
  providedIn: 'root'
})
export class PlayerService {
apiUrl:string="http://localhost:4300/player";
apiurl:string="http://localhost:4300/register"

  constructor( private ht:HttpClient) { }
getAllPlayers():Observable<any>
{
return this.ht.get(this.apiUrl,{responseType:'json'})
}

getPlayerById(i : number) : Observable<any> {
  return this.ht.get(this.apiUrl+ '/' + i,{responseType: 'json'})

}
addPlayer(pl:Players){
    const httpOptions={
headers:new HttpHeaders({'Content-Type':'application/json'})

    }
    return this.ht.post(this.apiUrl,JSON.stringify(pl),httpOptions)

}

registerPlayer(rp:RegisterPlayer){
const httpOptions={
  headers:new HttpHeaders({'Content-Type':'application/json'})
}
return this.ht.post(this.apiurl,JSON.stringify(rp),httpOptions)

}
login(uid:any,pwd:number){

return this.ht.get("http://localhost:4300/login"+'/'+uid+'/'+pwd,{responseType:'json'})
}

deletePlayer(id:number): Observable<any>
{
  return this.ht.delete(this.apiUrl+'/'+id,{responseType:'json'})
}


updatePlayer(pObj : Players) : Observable<any>{
  const headers = {
    headers:new HttpHeaders({'content-type':'application/json'})
  }
    return this.ht.put(this.apiUrl ,JSON.stringify(pObj),headers)
    alert(pObj)
}

}
