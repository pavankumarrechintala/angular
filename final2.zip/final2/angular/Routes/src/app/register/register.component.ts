import { Component, OnInit } from '@angular/core';
import {RegisterPlayer} from '../models1/regmodel';
import { Router } from '@angular/router';
import { PlayerService } from '../services/player.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
pava:RegisterPlayer
  constructor(private rt:Router,private ps:PlayerService) { 

    this.pava=new RegisterPlayer
  }


    
  btnclk(regfrm){

   
    if(regfrm.valid){
      this.ps.registerPlayer(this.pava).subscribe((data) => {
        console.log(data); 
       alert(JSON.stringify(data))
    
      this.rt.navigate(['login'])
    })}
  
  else{
    alert('not inserted');
  }
    }
  
   

  ngOnInit() {
  }




}
