export class RegisterPlayer{
userid:string
address:any
street:string
city:string
emailid:any
phonenumber:number
password:any

}