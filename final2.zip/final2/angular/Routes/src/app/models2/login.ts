export class Login{

userid:any
password:number

}