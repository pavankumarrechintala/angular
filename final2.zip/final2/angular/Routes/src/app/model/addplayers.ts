export class Players{
id:number
name:string
image:any
country:string



}