import { Component, OnInit } from '@angular/core';
import {Employee} from '../model/employeemodel'
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
emp:Employee
  constructor() {

    this.emp=new Employee();
   }

   btnSubmit(empfrm){
    let frmValid : boolean
    frmValid = empfrm.valid
    if(frmValid == true)
    alert('Form Submitted to the server ....')
    else
    alert("Invalid Form .. ")
   }
  ngOnInit() {
  }

}
