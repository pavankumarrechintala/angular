export class Employee{
     id:number
     name:string
     city:string
     salary:number
}