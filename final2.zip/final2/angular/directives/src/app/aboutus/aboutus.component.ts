import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent {


  a: string = "angular"
  name: any
  Names: string[] = []
  students: any[] = []
  constructor() {
    this.Names = ["pavan", "santhosh", "jagadish"]

    this.students = [


      { "name": "pavanrejintala", "city": "hyderabad", "place": "ptc" },
      { "name": "santhosh", "city": "chennai", "place": "arambur"},
      { "name": "jagadish", "city": "bangalore", "place": "electonics city" }

    ]
  }

}
