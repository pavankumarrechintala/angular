import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  name:any
  font:any
  colour:any
  fun(nm:any){
    this.name=nm.value
  }
  fun2(cl:any){
    this.font=cl.value
  }
  fun3(ap:any)
  {

    this.colour=ap.value
  }
  constructor() {
    
   }

  ngOnInit() {
  }

}

