import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../services/service.service';
import {Router} from '@angular/router'


@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.css']
})
export class MyprofileComponent implements OnInit {
b:any[]=[]
  constructor(private ps:ServiceService,private rt:Router) {
let i=localStorage.getItem("uname")
    this.ps.getprofile(i).subscribe((data)=>{
      console.log(JSON.stringify(data))
this.b=data[0]
    })
   }

   btnclk(regfrm){
  console.log(JSON.stringify(this.b))
  this.ps.update(this.b).subscribe((data)=>{
console.log(data)
})}
  ngOnInit() {
  }

}
