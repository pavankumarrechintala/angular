import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../services/service.service';
import {Router} from '@angular/router';
import {Addpost} from '../models/addpost';

@Component({
  selector: 'app-mypost',
  templateUrl: './mypost.component.html',
  styleUrls: ['./mypost.component.css']
})
export class MypostComponent implements OnInit {
mypost:Addpost
postlist:any[]=[]
  constructor(private rt:Router,private ps:ServiceService) {
    this.mypost=new Addpost()

   }
   btnEditClick(id){
    this.rt.navigate(['updatepost/'+id])

   }

   btnDelClick(id){
    this.ps.deletePlayer(id).subscribe((data)=>{
      alert(JSON.stringify(data)) 
      location.reload();
      })

   }

  ngOnInit() {
    this.mypost.userid=localStorage.getItem('uname');
   this.ps.getPostByUserId(this.mypost.userid).subscribe((res)=>{
    console.log(res)
    this.postlist=res
    
        })

  }

}
