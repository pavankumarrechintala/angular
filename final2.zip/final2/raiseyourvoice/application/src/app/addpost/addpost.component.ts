import { Component, OnInit } from '@angular/core';
import {Addpost} from '../models/addpost';
import {Router} from '@angular/router';
import {ServiceService} from '../services/service.service'
@Component({
  selector: 'app-addpost',
  templateUrl: './addpost.component.html',
  styleUrls: ['./addpost.component.css']
})
export class AddpostComponent implements OnInit {
pav:Addpost
url:string=''

  constructor(private ps:ServiceService,private rt:Router) {

    this.pav=new Addpost()
   }


   btnclk(addfrm){

if(addfrm.valid){

  this.pav.image = this.pav.image.replace('data:image/jpeg;base64,','')
  this.pav.image = this.pav.image.replace('data:image/jpg;base64,','')
  this.pav.image = this.pav.image.replace('data:image/png;base64,','')

this.pav.userid=localStorage.getItem('uname');
  this.ps.addPost(this.pav).subscribe((data) => {
    console.log(data); 
   alert(JSON.stringify(data))
console.log("Added Post")
location.reload();

})}

else{
alert('Not inserted');
}
}

fileselect(event){
  if(event.target.files){
    var reader  = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (ev:any)=>{
      this.url = ev.target.result
      this.pav.image = reader.result
    }
  }
}


  ngOnInit() {
  }

}
