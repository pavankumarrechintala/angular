import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Observable } from 'rxjs';
import {Register_user} from '../models/regmodel';
import {Login} from '../models/login';
import {Addpost} from '../models/addpost'
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  apiUrl:string="http://localhost:4700/register";
  apiurl:string="http://localhost:4700/post";
apiurll:string="http://localhost:4700/comment"
  constructor(private ht:HttpClient) { }


  getAllPosts():Observable<any>
  {
  return this.ht.get("http://localhost:4700/post/j",{responseType:'json'})
  }
  getprofile(i):  Observable<any>
  {

  return this.ht.get("http://localhost:4700/register"+'/'+i,{responseType:'json'})
  }
  
  getPostByUserId(i : any) : Observable<any> {
    return this.ht.get(this.apiurl+ '/' + i,{responseType: 'json'})
  console.log(i)
  }
  getPostByPostid(i : any): Observable<any> {
    return this.ht.get("http://localhost:4700/postupdate"+ '/' + i,{responseType: 'json'})
  console.log(i)
  }

  registermember(rp:Register_user){
    const httpOptions={
      headers:new HttpHeaders({'Content-Type':'application/json'})
    }
    return this.ht.post(this.apiUrl,JSON.stringify(rp),httpOptions)
    
    }

    addPost(ad:Addpost){
      const httpOptions={
        headers:new HttpHeaders({'Content-Type':'application/json'})
      }
      return this.ht.post(this.apiurl,JSON.stringify(ad),httpOptions)
      
      }

      login(uid:any,pwd:any):Observable<any>{

        return this.ht.get("http://localhost:4700/login"+'/'+uid+'/'+pwd,{responseType:'json'})
        }
        
        deletePlayer(id:number): Observable<any>
        {
          return this.ht.delete(this.apiurl+'/'+id,{responseType:'json'})
        }

        updatePlayer(pObj : Addpost) : Observable<any>{
          const headers = {
            headers:new HttpHeaders({'content-type':'application/json'})
          }
            return this.ht.put(this.apiurl ,JSON.stringify(pObj),headers)
            alert(pObj)
        }
        update(profile) :Observable<any>{

          const headers = {
            headers:new HttpHeaders({'content-type':'application/json'})
          }
            return this.ht.put(this.apiUrl ,JSON.stringify(profile),headers)
            
        }
       addcommemt(cobj):Observable<any>{
          const headers = {
            headers:new HttpHeaders({'content-type':'application/json'})
          }
         return this.ht.post(this.apiurll,cobj,headers)

        }

        getcomment(i : any):Observable<any>{
          return this.ht.get(this.apiurll+'/'+i,{responseType: 'json'})     
           }

}
