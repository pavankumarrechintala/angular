import { Component, OnInit } from '@angular/core';
import {ServiceService} from '../services/service.service';
import {Router} from '@angular/router'
import {Addpost} from '../models/addpost'
import { comment } from '../models/comment';
@Component({
  selector: 'app-forums',
  templateUrl: './forums.component.html',
  styleUrls: ['./forums.component.css']
})
export class ForumsComponent implements OnInit {
  pavan:any[]=[]
pav:Addpost
cobj:comment
cmobj:comment
name:any
  constructor(private ps:ServiceService,private rt:Router) {
    this.cobj = new comment();
     }

        btncmt(pid,cmt){

     

         this.cobj.pid=pid;
         this.cobj.comments=cmt;
         this.cobj.commentedby= localStorage.getItem('uname');
        

         if(localStorage.getItem('uname')){
           this.ps.addcommemt(this.cobj).subscribe((data) => {
  
           alert(JSON.stringify(data))
        console.log("Added comment")
  
         })}
         else{
           alert("Please SignIn to comment your post")
           this.rt.navigate(['login'])
         }
        

        }

        btnimage(pid){
      
          this.rt.navigate(['pdetail/'+pid])
        }
 

  ngOnInit() {

    this.ps.getAllPosts().subscribe((res)=>{
   console.log(res)
      this.pavan=res

      
          })

     
          
  }
  

}
