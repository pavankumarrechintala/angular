import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router';
import {FormsModule} from '@angular/forms';
import {HttpClientModule } from '@angular/common/http'


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ForumsComponent } from './forums/forums.component';
import { AddpostComponent } from './addpost/addpost.component';
import { MypostComponent } from './mypost/mypost.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { UpdatepostComponent } from './updatepost/updatepost.component';
import { PdetailComponent } from './pdetail/pdetail.component';
import {CarouselModule} from  'ngx-bootstrap/carousel';
import { MyprofileComponent } from './myprofile/myprofile.component'


var totalroutes:Routes=[
  {path:'home',component:HomeComponent},
  {path:'forums',component:ForumsComponent},
  {path:'addpost',component:AddpostComponent},
  {path:'mypost',component: MypostComponent},
  {path:'register',component: RegisterComponent},
 {path:'login',component: LoginComponent},
 {path:'updatepost/:id',component:UpdatepostComponent},
 {path:'pdetail/:id',component:PdetailComponent },
 {path:'profile',component: MyprofileComponent}
  ];
  

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ForumsComponent,
    AddpostComponent,
    MypostComponent,
    RegisterComponent,
    LoginComponent,
    UpdatepostComponent,
    PdetailComponent,
    MyprofileComponent
  
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(totalroutes),FormsModule,HttpClientModule,CarouselModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
