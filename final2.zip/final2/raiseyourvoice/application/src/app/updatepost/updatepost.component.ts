import { Component, OnInit } from '@angular/core';
import {Addpost} from '../models/addpost';
import {ActivatedRoute, Router } from '@angular/router';
import {ServiceService} from '../services/service.service'
@Component({
  selector: 'app-updatepost',
  templateUrl: './updatepost.component.html',
  styleUrls: ['./updatepost.component.css']
})
export class UpdatepostComponent implements OnInit {
pav:Addpost
url:string=''
  constructor(private acr: ActivatedRoute,private ps:ServiceService,private rt:Router) {

    this.pav=new Addpost()
   }

    
  btnclk(addfrm){
    if(addfrm.valid){
      
  this.pav.image = this.pav.image.replace('data:image/jpeg;base64,','')
  this.pav.image = this.pav.image.replace('data:image/jpg;base64,','')
  this.pav.image = this.pav.image.replace('data:image/png;base64,','')

      this.ps.updatePlayer(this.pav).subscribe((data)=>{
        this.rt.navigate(['forums'])
      })        
    }
  }

  fileselect(event){
    if(event.target.files){
      var reader  = new FileReader();
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (ev:any)=>{
        this.url = ev.target.result
        this.pav.image = reader.result
      }
    }

  }
  ngOnInit() {
    let i =  parseInt(this.acr.snapshot.params["id"])
   this.ps.getPostByPostid(i).subscribe((data)=>{
     console.log(JSON.stringify(data))
    this.pav = data[0];
     })


    }
}