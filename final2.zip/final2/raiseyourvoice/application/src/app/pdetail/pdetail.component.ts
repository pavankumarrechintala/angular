import { Component, OnInit } from '@angular/core';
import { comment} from '../models/comment';
import {Addpost} from '../models/addpost';
import {ServiceService} from '../services/service.service';

import {ActivatedRoute, Router } from '@angular/router';
import { stringify } from '@angular/core/src/render3/util';

@Component({
  selector: 'app-pdetail',
  templateUrl: './pdetail.component.html',
  styleUrls: ['./pdetail.component.css']
})
export class PdetailComponent implements OnInit {
  cobj:comment
  pavan:any[]=[]
  post:any[];
  constructor(private ps:ServiceService,private rt:Router,private acr:ActivatedRoute) {
    this.cobj = new comment();
   }



   
   btncmt(pid,cmt){

    this.cobj.pid=pid;
    this.cobj.comments=cmt;
    this.cobj.commentedby= localStorage.getItem('uname');
    this.cobj.userid= localStorage.getItem('uname');
    if(localStorage.getItem('uname')){
      this.ps.addcommemt(this.cobj).subscribe((data) => {
location.reload();

      //alert(JSON.stringify(data))
   console.log("Added comment")

    })}
    else{
      alert("Please SignIn to comment your post")
      this.rt.navigate(['login'])
    }
   

   }
  ngOnInit() {

    let i =  parseInt(this.acr.snapshot.params["id"])
    this.ps.getPostByPostid(i).subscribe(data=>{
this.post=data[0];
    })
    this.ps.getcomment(i).subscribe((data)=>{
      console.log(JSON.stringify(data))
     this.pavan= data;
      })


    // this.ps.getcomment().subscribe((data)=>{
           
    //   this.cmobj=data
    //   console.log(JSON.stringify(this.cmobj))
    // })
  }

}



















