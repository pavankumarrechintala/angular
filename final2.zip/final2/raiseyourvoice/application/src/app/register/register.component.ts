import { Component, OnInit } from '@angular/core';
import {Register_user } from '../models/regmodel';
import {Router} from '@angular/router';
import {ServiceService} from '../services/service.service'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
pav:Register_user
  constructor(private ps:ServiceService,private rt:Router) { 

    this.pav=new Register_user()
  }


     
  btnclk(regfrm){

   
    if(regfrm.valid){
      this.ps.registermember(this.pav).subscribe((data) => {
        console.log(data); 
       alert(JSON.stringify(data))
    console.log("Registration Completed")
      this.rt.navigate(['login'])
    })}
  
  else{
    alert('Not inserted');
  }
    }
  

  ngOnInit() {
  }

}
