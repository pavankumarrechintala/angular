import { Component, OnInit } from '@angular/core';
import {Login} from '../models/login';
import {Router} from '@angular/router';
import {ServiceService} from '../services/service.service'
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  uid:string="";
  pwd:any="";
  pav:Login;
  
  constructor(private ps:ServiceService,private rt:Router) {
    this.pav=new Login();
   }

   btnloginClick(u,p){
          console.log(u+p)
    this.ps.login(u,p).subscribe((data) => {

   if (data.length > 0) {
    localStorage.setItem("uname",u)
  
    this.rt.navigate(['home'])
  }
else{
  alert('invalid credintials')
}
})
}


  ngOnInit() {
  }

}
