export class Addpost{
userid:any
pid :number
title:string
image:any
description:string
city:string
area:string
date:Date = new Date();
comments:string
commentedby:string
firstname:string







}