

export class Register_user{
userid:string
firstname:string
lastname:string
email:any
country:string
state:string
city:string
image:any
contactnumber:number
password:string



}