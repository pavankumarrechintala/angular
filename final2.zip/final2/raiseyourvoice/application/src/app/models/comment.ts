export class comment{
    userid:any
    pid:number
    comments:string
    commentedby:string
    date:Date=new Date();
    image:any
}