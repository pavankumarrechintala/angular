import { Component,DoCheck } from '@angular/core';
import {of} from 'rxjs';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  
  lgval: Observable<string>

  constructor(private rt:Router) {
  }

  private CheckLocalStore(): Observable<any> {
      return of(localStorage.getItem("uname"));
  }


  logOutClick()
  {
      localStorage.removeItem("uname")
      this.rt.navigate(['home'])
  }

  ngDoCheck() {
      this.CheckLocalStore().subscribe((data) => { this.lgval = data })
  }}