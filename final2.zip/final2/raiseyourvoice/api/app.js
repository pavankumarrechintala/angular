var fs=require('fs')

var path=require('path')
var bodyparser=require('body-parser')
var express=require('express')
var promise=require('bluebird')
var pav=express();

var options={promiseLib:promise}
var total=require('pg-promise')(options)
 var cs='postgres:postgres:root@localhost:5432/raiseyourvoice_db'

 var db=total(cs)
 
 pav.set('port',process.env.PORT||4700)
 pav.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Cache-Control, Pragma,Origin,Authorization, Content-Type, X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
 });

 pav.use(bodyparser.urlencoded({limit:"100mb",extended:true}));
 pav.use(bodyparser.json({limit:"100mb"}));

 pav.use(express.static(path.join(__dirname,'images')));
 pav.use(express.static(path.join(__dirname,'uimages')))

 pav.get('/',(req,res)=>{
res.send('DATBASE CONNECTED')
 })



 pav.get('/register',(req,res,next)=>{
    db.any('select * from Register_user').then(
        (data)=>{
            res.send(data)
        })
     })
    
    
     pav.get('/register/:id',(req,res,next)=>{
        pid = req.params.id
       db.any('select * from Register_user where userid = $1', pid).then(
       (data)=>{
           res.send(data)
       })
       })
        
       pav.delete('/register/:id',(req,res,next)=>{

        var pid=req.params.id
        db.any('delete from Register_user where userid=$1',pid).then(
            (data)=>{
                res.send({'message':'RECORD DELETED'})
            })
       })

       pav.get('/login/:id/:pwd',(req,res,next)=>{
            console.log("pad")
        var pid=req.params.id
        var pw=req.params.pwd
        db.any('select * from Register_user where userid=$1 and password=$2',[pid,pw]).then(
            (data)=>{
                res.send(data)
        
       })
    })
    


       pav.post('/register',(req,res,next)=>{
           
    
        var i=parseInt(req.body.userid)
        var a=req.body.firstname
        var st=req.body.lastname
        var ct=req.body.email
        var c=req.body.country
        var s=req.body.state
        var ei=req.body.city
       // var im=req.body.image
        var pn=req.body.contactnumber
        var pa=req.body.password
    db.any('insert into Register_user(userid,firstname,lastname,email,country,state,city,contactnumber,password) values($1,$2,$3,$4,$5,$6,$7,$8,$9)',[i,a,st,ct,c,s,ei,pn,pa]).then((data)=>{
    
        res.send({'message':'INSERTED REGISTER FORM'})
    })
    
    
       })


       
   pav.put('/register',(req,res,next)=>{
       
    

    var i=parseInt(req.body.userid)
    var a=req.body.firstname
    var st=req.body.lastname
    var ct=req.body.email
    var c=req.body.country
    var s=req.body.state
    var ei=req.body.city
    var im=req.body.image
    var pn=req.body.contactnumber
    var pa=req.body.password
db.any('update Register_user set firstname=$1,lastname=$2,email=$3,country=$4,state=$5,city=$6,image=$7,contactnumber=$8,password=$9 where userid=$10',[a,st,ct,c,s,ei,im,pn,pa,i]).then(

           (data)=>{
               res.send({'message':'updated REGISTER table successfully'})
           }
)

   })

   //------Addpost api-------------


   pav.get('/post/j',(req,res,next)=>{
    db.any('select u.firstname,a.userid,a.pid,a.title,a.image,a.description,a.city,a.area,a.date from  Register_user as u inner join Addpost_user as a on  u.userid=a.userid;').then(
        (data)=>{
            res.send(data)
        })
     })


     pav.get('/post',(req,res,next)=>{
        db.any('select * from Addpost_user').then(
            (data)=>{
                res.send(data)
            })
         })



     pav.get('/post/:id',(req,res,next)=>{
         pid=req.params.id
        db.any('select * from Addpost_user where userid=$1',pid).then(
            (data)=>{
                res.send(data)
            })
         })

         pav.get('/postupdate/:id',(req,res,next)=>{
            ppid=req.params.id
           db.any('select * from Addpost_user where pid=$1',ppid).then(
               (data)=>{
                   res.send(data)
               })
            })
   pav.post('/post',(req,res,next)=>{
       console.log(req.body)
    var fileName = req.body.pid + '.png'
    var cfn = path.join(__dirname,'images/'+fileName)
    fs.writeFile(cfn, req.body.image,'base64',(err)=>{
            if(err)
                console.log('Unable to Save Image..')
                else
                console.log('Image Saved Success...')
    })

    var i=parseInt(req.body.userid)
    var a=parseInt(req.body.pid)
    var st=req.body.title
    var ct="http://localhost:4700/" + req.body.pid+'.png'
    
    var c=req.body.description
    var s=req.body.city
    var ei=req.body.area
    var im=req.body.date
    var pn=req.body.postedby
  
db.any('insert into Addpost_user(userid,pid,title,image,description,city,area,date,postedby) values($1,$2,$3,$4,$5,$6,$7,$8,$9)',[i,a,st,ct,c,s,ei,im,pn]).then(

           (data)=>{
               res.send({'message':'inserted into addpost_user successfully'})
           }
)

   })

   
   pav.delete('/post/:id',(req,res,next)=>{

    var opid=req.params.id
    db.any('delete from Addpost_user where pid=$1',opid).then(
        (data)=>{
            res.send({'message':'RECORD DELETED'})
        })
   })


   pav.put('/post',(req,res,next)=>{
   
    console.log(req.body)
    var fileName = req.body.pid + '.png'
    var cfn = path.join(__dirname,'images/'+fileName)
    fs.writeFile(cfn, req.body.image,'base64',(err)=>{
            if(err)
                console.log('Unable to Save Image..')
                else
                console.log('Image Saved Success...')
    })

 var i=parseInt(req.body.userid)
 var a=parseInt(req.body.pid)
 var st=req.body.title
 var ct="http://localhost:4700/" + req.body.pid+'.png'
 
 var c=req.body.description
 var s=req.body.city
 var ei=req.body.area
 var im=req.body.date
 var pn=req.body.postedby

db.any('update  Addpost_user set pid=$1,title=$2,image=$3,description=$4,city=$5,area=$6,date=$7,postedby=$8 where userid=$9',[a,st,ct,c,s,ei,im,pn,i]).then(

        (data)=>{
            res.send({'message':'updated addpost_user successfully'})
        }
)

})


//--------comments-------

pav.post('/comment',(req,res,next)=>{
    var p = req.body.pid
    var c = req.body.comments
    var cb = req.body.commentedby
    var d = req.body.date
    var u=req.body.userid

    db.any('insert into Comment_user(pid,comments,commentedby,date,userid) values($1,$2,$3,$4,$5)',[p,c,cb,d,u]).then((data)=>{
        res.send(data)
    })
})

pav.get('/comment',(req,res,next)=>{
    db.any('select * from Comment_user').then((data)=>{
        res.send(data)
    })
})
pav.get('/comment/:id',(req,res,next)=>{
    
    c=req.params.id
    db.any('select u.firstname,u.lastname,c.userid,c.pid,c.comments,c.commentedby,c.date from Register_user as u join comment_user as c on u.userid=c.userid',c).then((data)=>{
        res.send(data)
    })
})




 
pav.listen(pav.get('port'),(err)=>{
    if(err)
    console.log('server not strated ...')
    else 
    console.log('server Started at  : http://localhost:4700')
    })
    