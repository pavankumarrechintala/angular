var path=require('path')
var express=require("express")
var router=express.Router();

router.get('/home',(req,res)=>{
    res.sendFile(path.join(__dirname,'./admin/home.html'))

})



router.get('/addproduct',(req,res)=>{
    res.sendFile(path.join(__dirname,'./admin/addproduct.html'))

})


router.get('/updateproduct',(req,res)=>{
    res.sendFile(path.join(__dirname,'./admin/updateproduct.html'))

})

module.exports=router
