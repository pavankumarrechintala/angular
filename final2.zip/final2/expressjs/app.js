var path = require('path')
var express = require('express')
var app = express();


var adminRoutes = require('./adminRoutes')
var userRoutes = require('./userRoutes')

app.set('port', process.env.PORT || 4900)

app.use(express.static(path.join(__dirname, 'pub')))



app.use('/user', userRoutes)
app.use('/admin', adminRoutes)

//app.use(function(req,res){
//  res.status(404)
//res.sendFile(path.join(__dirname,'Errorpage.html'))

//})

app.use('**', (req, res) => {
    res.status(404)
    res.sendFile(path.join(__dirname, 'Errorpage.html'))
})

app.listen(app.get('port'), (err) => {
    if (err) {
        console.log("Error")
    }
    else {
        console.log("server started at  : http://localhost:" + app.get('port'))

    }
})