var path=require('path')
var express=require('express')
var router=express.Router();

router.get('/home',(req,res)=>{
    res.sendFile(path.join(__dirname,'./user/home.html'))

})



router.get('/searchproduct/:mobile',(req,res)=>{
var product=req.params.mobile
console.log("searched item is:"+product)

    res.sendFile(path.join(__dirname,'./user/searchproduct.html'))

})


router.get('/showcart',(req,res)=>{
    res.sendFile(path.join(__dirname,'./user/showcart.html'))

})

module.exports=router
