var fs=require('fs')
var path=require('path')
var bodyparser=require('body-parser')
var express=require('express')
var promise=require('bluebird')
var pav=express();

var options={promiseLib:promise}
var total=require('pg-promise')(options)
 var cs='postgres:postgres:root1@localhost:5432/pavanexam'

 var db=total(cs)
 
 pav.set('port',process.env.PORT||4300)


 pav.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');
 res.setHeader('Access-Control-Allow-Methods', '*');
 res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
 next();
})

pav.use(bodyparser.urlencoded({limit:"50mb", extended:true}));
pav.use(bodyparser.json({limit:"50mb"}));


pav.use(express.static(path.join(__dirname,'images')))
pav.get('/',(req,res)=>{
res.send('DATBASE CONNECTED')
})




pav.get('/user',(req,res,next)=>{
    db.any('select * from users').then(
        (data)=>{
            res.send(data)
        })
     })


     pav.get('/Question',(req,res,next)=>{
        db.any('select * from Questions').then(
            (data)=>{
                res.send(data)
            })
         })
        

    
         pav.get('/examiner',(req,res,next)=>{
            db.any('select * from admin').then(
                (data)=>{
                    res.send(data)
                })
             })
            

             pav.listen(pav.get('port'),(err)=>{
                if(err)
                console.log('server not strated ...')
                else 
                console.log('server Started at  : http://localhost:4300')
                })
                





