export class Login{
    userid:any
    password:string
}