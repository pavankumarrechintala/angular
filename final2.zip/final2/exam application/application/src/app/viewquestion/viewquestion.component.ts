import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExamService } from '../sevices/exam.service';

@Component({
  selector: 'app-viewquestion',
  templateUrl: './viewquestion.component.html',
  styleUrls: ['./viewquestion.component.css']
})
export class ViewquestionComponent implements OnInit {

  constructor(private rt:Router,private ps:ExamService) { }

  ngOnInit() {
    this.ps.seconds=0;
    this.ps.qnProgress=0;
    this.ps.getQuestions().subscribe{
      (data:any)=>{
        this.ps.qns=data;
        this.startTimer();
      }
    }


  }
  startTimer(){
    this.ps.timer=setInterval(()=>{
      this.ps.seconds++;
    },1000);
  }

}
