import { Injectable } from '@angular/core';
import {Login} from '../model/login';
import { HttpClient} from '@angular/common/http'


@Injectable({
  providedIn: 'root'
})
export class ExamService {


  qns:any[];
  seconds:number;
  timer;
  qnProgress:number;
  
  constructor(private ht:HttpClient) { }
  login(:any,pwd:any):Observable<any>{

    return this.ht.get("http://localhost:4700/login"+'/'+uid+'/'+pwd,{responseType:'json'})
    }

}
