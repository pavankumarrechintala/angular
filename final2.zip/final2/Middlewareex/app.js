
var cookie=require('cookie-parser')
var express=require('express')
var app=express();

app.set('port',4000)

app.use(cookie())

app.use(function(req,res,next){
    console.log("last accessed date is:"+Date.now())
      next()
  
  
  })
  

app.get('/',(req,res)=>{
    res.cookie('name',"pavan")

    res.send("<h1>  how am i</h1>")



})
app.get('/pvnq',(req,res)=>{
   console.log(req,cookie.name)
   res.cookie('password',"loco")
    res.send("<h1>boon  how am i</h1>")
})






app.listen(app.get('port'),(err)=>{
    if(err){
        console.log("Error")
    }
    else
    {
        console.log("server started at  : http://localhost:"+app.get('port'))

    }
})