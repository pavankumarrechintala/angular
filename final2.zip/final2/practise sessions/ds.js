module.exports= (req, res)=> {
    console.log(req.url);
    if(req.url =="/")
        {
    res.end("<h1>NodeJS Learning....</h1>")
        }
else if (req.url =="/home"){
    res.writeHead(200,{"content-type":"text/html"});
    res.end("home page");
    

        
}
    
else if (req.url =="/login"){
        res.end("<h1>Login Page </h1>....");
}
    
else if (req.url =="/register"){
        res.end("<h1>Register Page </h1>....");
}
else
    {
        res.end("Invalid Requ....");
    }
}