var http = require('http')

var reqhandler = require("./ds.js");
var server = http.createServer();

server.on("request", reqhandler)
server.listen(3004, function (err) {
    if (err) {
        console.log("Error in starting the server ..")
    }
    else {
        console.log("Server started at : " + new Date());
    }
})
