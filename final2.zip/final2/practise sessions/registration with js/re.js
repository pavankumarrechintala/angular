function pavan() {

    var e = document.getElementById("po").value
    if (e= null) {
        alert("enter email")
    }
    else {
        alert("success")
    }
}




