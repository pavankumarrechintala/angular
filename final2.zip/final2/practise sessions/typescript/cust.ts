class Customer{

    private custid:number;
    private custname:string;
    private custcity:string;
    
    public setCustomer(i:number,nm:string,c:string)
    
    {
    this.custid=i;
    this.custname=nm;
    this.custcity=c;
    
    console.log("CUSTOMER DATA SET AS:")
    }
    
    
    public getCustomer(){
    console.log("id=%s,name=%s,city=%s",this.custid,this.custname,this.custcity)
    
    
    
    }
   // public neta( hra:number, pf:number)
    //{
      //  console.log("net salary is"+(this.salary+hra-pf))
    //}
    }
    
    
    var obj:Customer=new Customer();
    obj.setCustomer(1003,'santhosh','hyderbad')
    obj.getCustomer();
  // empobj.neta(4,5)
    