var Customer = /** @class */ (function () {
    function Customer() {
    }
    Customer.prototype.setCustomer = function (i, nm, c) {
        this.custid = i;
        this.custname = nm;
        this.custcity = c;
        console.log("CUSTOMER DATA SET AS:");
    };
    Customer.prototype.getCustomer = function () {
        console.log("id=%s,name=%s,city=%s", this.custid, this.custname, this.custcity);
    };
    return Customer;
}());
var obj = new Customer();
obj.setCustomer(1003, 'santhosh', 'hyderbad');
obj.getCustomer();
// empobj.neta(4,5)
