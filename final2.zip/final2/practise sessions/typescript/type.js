var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.setEmployee = function (i, nm, sl, c) {
        this.id = i;
        this.name = nm;
        this.salary = sl;
        this.city = c;
        console.log("EMPLOYEE DATA SET AS:");
    };
    Employee.prototype.getEmployee = function () {
        console.log("id=%s,name=%s,salary=%s,city=%s", this.id, this.name, this.salary, this.city);
    };
    Employee.prototype.neta = function (hra, pf) {
        console.log("net salary is" + (this.salary + hra - pf));
    };
    return Employee;
}());
var empobj = new Employee();
empobj.setEmployee(1002, 'pavanr', 222324, 'hyderbad');
empobj.getEmployee();
empobj.neta(4, 5);
