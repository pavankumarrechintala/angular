class Employee{

private id:number;
private name:string;
 private salary:number;
private city:string;

public setEmployee(i:number,nm:string,sl:number,c:string)

{
this.id=i;
this.name=nm;
this.salary=sl;
this.city=c;

console.log("EMPLOYEE DATA SET AS:")
}


public getEmployee(){
console.log("id=%s,name=%s,salary=%s,city=%s",this.id,this.name,this.salary,this.city)



}
public neta( hra:number, pf:number)
{
    console.log("net salary is"+(this.salary+hra-pf))
}
}


var empobj:Employee=new Employee();
empobj.setEmployee(1002,'pavanr',222324,'hyderbad')
empobj.getEmployee();
empobj.neta(4,5)


