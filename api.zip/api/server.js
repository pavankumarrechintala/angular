var express=require('express')
var promise=require('bluebird')
var bp=require('body-parser')
var options={promiseLib:promise}
var pgp=require('pg-promise')(options)
var route=express()

 route.use(bp.urlencoded({extended:true}))
 route.use(bp.json())

 route.set('port',process.env.PORT||4248)

 var cs="postgres://postgres:root@192.168.0.129/GetSurv"

 route.get('/',(req,res,next)=>{
     var myDb=pgp(cs)
     myDb.any('select fn_get()').then((data)=>{
         res.send(data)
     })
     pgp.end()
 })

 route.get('/:id',(req,res,next)=>{
     var i=req.params.id
    var myDb=pgp(cs)
    myDb.any('select fn_getid($1)',i).then((data)=>{
        res.send(data)
    })
    pgp.end()
})
route.get('/login/:id/:ip',(req,res,next)=>{
    var i=req.params.id;
    var p=req.params.ip;
   var myDb=pgp(cs)
   myDb.any('select fn_userlogin($1,$2)',[i,p]).then((data)=>{
       res.send(data)
   })
   pgp.end()
})

route.put('/:userid',(req,res,next)=>{
        var i=req.body.userid
        var p=req.body.password
    var myDb=pgp(cs)
       myDb.any("select fn_changepwd($1,$2)",[i,p]).then((data)=>{
           res.send({"message":"updated succesfully"})
       })
       pgp.end()
    })

route.post('/',(req,res,next)=>{
    var f=req.body.firstname;
    var l=req.body.lastname;
    var e=req.body.emailid
    var p=req.body.password
    var mo=req.body.mobileno
    var g=req.body.gender
    var a=req.body.address
   var myDb=pgp(cs)
   myDb.any("select fn_useradd1($1,$2,$3,$4,$5,$6,$7)",[f,l,e,p,mo,g,a]).then((data)=>{
       res.send({"message":"inserted succesfully"})
   })
   pgp.end()
})


route.put('/update/:userid',(req,res,next)=>{
    var i=req.params.userid
    var f=req.body.firstname;
    var l=req.body.lastname;
    var mo=req.body.mobileno;
    var a=req.body.address;
var myDb=pgp(cs)
   myDb.any("select fn_userupdate($1,$2,$3,$4,$5)",[f,l,mo,a,i]).then((data)=>{
       res.send({"message":"updated succesfully"})
   })
   pgp.end()
})

route.listen(route.get('port'),(err)=>{
    if(err){
        console.log("server error..")
    }
    else{
        console.log("server is started...  http://localhost:"+route.get('port'))
    }
})